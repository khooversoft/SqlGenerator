-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[VwGF_TLR_RES_CREDIT_LIABILITY]
AS
   SELECT
      x.[LNUM],
      x.[DBID],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[LIABILITYID],
      x.[PRIMARY_BNUM],
      x.[PRIMARY_DBID],
      x.[SECONDARY_BNUM],
      x.[SECONDARY_DBID],
      x.[CREDIT_TRADEID],
      x.[CLOSE_DATE],
      x.[ACCOUNT_IDENTIFIER],
      x.[OPENED_DATE],
      x.[OWNERSHIP_TYPE],
      A0.[Descript] AS [OWNERSHIP_TYPE_X],
      x.[PAID_DATE],
      x.[REPORTED_DATE],
      x.[STATUS_DATE],
      x.[ACCOUNT_STATUS_TYPE],
      A1.[Descript] AS [ACCOUNT_STATUS_TYPE_X],
      x.[ACCOUNT_TYPE],
      A2.[Descript] AS [ACCOUNT_TYPE_X],
      x.[BALLOON_PAYMENT],
      x.[CHARGE_OFF_AMOUNT],
      x.[CHARGE_OFF_DATE],
      x.[COLATERAL_DESC],
      x.[CONSUMER_DISPUTE_INDC],
      x.[CREDIT_LIMIT_AMOUNT],
      x.[DEROGATORY_INDC],
      x.[HIGH_BALANCE],
      x.[HIGH_CREDIT],
      x.[LAST_ACTIVITY_DATE],
      x.[MANUAL_UPDATE_INDC],
      x.[MONTHLY_AMOUNT],
      x.[MONTHS_REMAINING],
      x.[MONTHS_REVIEWED],
      x.[ORIGINAL_CREDITOR_NAME],
      x.[PAST_DUE_AMOUNT],
      x.[TERMS_DESC],
      x.[TERMS_MONTHS],
      x.[TERMS_SOURCE_TYPE],
      A3.[Descript] AS [TERMS_SOURCE_TYPE_X],
      x.[UNPAID_BALANCE],
      x.[CREDIT_BUSINESS_TYPE],
      A4.[Descript] AS [CREDIT_BUSINESS_TYPE_X],
      x.[CREDIT_LOAN_TYPE],
      A5.[Descript] AS [CREDIT_LOAN_TYPE_X],
      x.[CREDIT_LOAN_OTHER_DESC],
      x.[CURRENT_RATING_CODE],
      x.[CURRENT_RATING_TYPE],
      A6.[Descript] AS [CURRENT_RATING_TYPE_X],
      x.[LATE_30_DAYS],
      x.[LATE_60_DAYS],
      x.[LATE_90_DAYS],
      x.[RECENT_ADVERSE_AMOUNT],
      x.[RECENT_ADVERSE_CODE],
      x.[RECENT_ADVERSE_TYPE],
      A7.[Descript] AS [RECENT_ADVERSE_TYPE_X],
      x.[RECENT_ADVERSE_DATE],
      x.[PATTERN_START_DATE],
      x.[PAYMENT_PATTERN],
      x.[VERIFY_BY_NAME],
      x.[VERIFY_COMMENT],
      x.[VERIFY_DATE],
      x.[VERIFY_STATUS_TYPE],
      A8.[Descript] AS [VERIFY_STATUS_TYPE_X],
      x.[LATE120DAYS],
      x.[CREDITLIABILITYID],
      x.[ACCOUNTBALANCEDATE],
      x.[BALLOONPAYMENTDUEDATE],
      x.[HIGHEST_ADVERSE_AMOUNT],
      x.[HIGHEST_ADVERSE_CODE],
      x.[HIGHEST_ADVERSE_TYPE],
      A9.[Descript] AS [HIGHEST_ADVERSE_TYPE_X],
      x.[HIGHEST_ADVERSE_DATE],
      x.[CREDITCOUNSELINGINDICATOR]
   FROM [clt_NetO].[GF_TLR_RES_CREDIT_LIABILITY] x
      LEFT JOIN [clt_NetO].[SymbolLookup] A0 on x.[OWNERSHIP_TYPE] = A0.[DBSYMBOL] AND A0.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A0.[COLUMNNAME] = 'OWNERSHIP_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A1 on x.[ACCOUNT_STATUS_TYPE] = A1.[DBSYMBOL] AND A1.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A1.[COLUMNNAME] = 'ACCOUNT_STATUS_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A2 on x.[ACCOUNT_TYPE] = A2.[DBSYMBOL] AND A2.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A2.[COLUMNNAME] = 'ACCOUNT_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A3 on x.[TERMS_SOURCE_TYPE] = A3.[DBSYMBOL] AND A3.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A3.[COLUMNNAME] = 'TERMS_SOURCE_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A4 on x.[CREDIT_BUSINESS_TYPE] = A4.[DBSYMBOL] AND A4.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A4.[COLUMNNAME] = 'CREDIT_BUSINESS_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A5 on x.[CREDIT_LOAN_TYPE] = A5.[DBSYMBOL] AND A5.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A5.[COLUMNNAME] = 'CREDIT_LOAN_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A6 on x.[CURRENT_RATING_TYPE] = A6.[DBSYMBOL] AND A6.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A6.[COLUMNNAME] = 'CURRENT_RATING_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A7 on x.[RECENT_ADVERSE_TYPE] = A7.[DBSYMBOL] AND A7.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A7.[COLUMNNAME] = 'RECENT_ADVERSE_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A8 on x.[VERIFY_STATUS_TYPE] = A8.[DBSYMBOL] AND A8.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A8.[COLUMNNAME] = 'VERIFY_STATUS_TYPE'
      LEFT JOIN [clt_NetO].[SymbolLookup] A9 on x.[HIGHEST_ADVERSE_TYPE] = A9.[DBSYMBOL] AND A9.[TableName] = 'GF_TLR_RES_CREDIT_LIABILITY' and A9.[COLUMNNAME] = 'HIGHEST_ADVERSE_TYPE'
   WHERE
      x.[ASAP_DeleteDateTime] IS NULL
      AND NOT EXISTS (SELECT * FROM [clt_NetO].[GF_TS_AUDIT_LOAN_DELETE] i WHERE x.[LNUM] = i.[DELETED_LNUM])
;
