-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------

CREATE TABLE [clt_NetO].[GF_TLR_REG_O]
(
   [LNUM]                             nchar(20)            NOT NULL,
   [BNUM]                             smallint             NOT NULL,
   [DBID]                             nchar(5)             NOT NULL,
   [ASAP_RecordEffectiveDateTime]     datetime2(7)         NOT NULL,
   [ASAP_DeleteDateTime]              datetime2(7)         NULL,
   [BOD_APPROVAL]                     nchar(1)             NULL,
   [O_DATE]                           datetime             NULL,
   [OFFICER_TITLE]                    nvarchar(40)         NULL,
   [NUMBER_OF_SHARES]                 int                  NULL,
   [REG_O_BORROWER]                   nchar(1)             NULL,
   [EMPLOYEE_BORROWER]                nchar(1)             NULL,
   [S_EMP_REGO_TYPE]                  nvarchar(8)          NULL,
   [EXEC_EDUC]                        nchar(1)             NULL,
   [EXEC_OFFIC_OTH]                   nvarchar(30)         NULL,
   [EXEC_OFFIC_YN]                    nvarchar(30)         NULL,
   [EXEC_FIRST_LIEN]                  nvarchar(30)         NULL,
   [BOD_APPROVAL_DATE]                datetime             NULL,
   [COMMITTEE_APPROVAL]               nchar(1)             NULL,
   [ASAP_ROW_HASH]                    nvarchar(64)         NULL,
   [ASAP_DML_FLAG]                    nvarchar(2)          NULL,
   [ASAP_CREATED_DATE]                datetime2(7)         NULL,
   [ASAP_UPDATED_DATE]                datetime2(7)         NULL,
   [ASAP_LINEAGE_ID]                  nvarchar(36)         NULL,
   [ASAP_ACTIVITY_ID]                 nvarchar(36)         NULL,
   [ASAP_TRIGGER_ID]                  nvarchar(36)         NULL,
   [ASAP_SRC_FILEPATH]                nvarchar(1000)       NULL,
   [ASAP_SRC_FILE_DATE]               datetime2(7)         NULL,
   [ASAP_SRC_NAME]                    nvarchar(36)         NULL
)
WITH (DISTRIBUTION = HASH ([LNUM]), CLUSTERED COLUMNSTORE INDEX)
;
