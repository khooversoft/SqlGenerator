CREATE SCHEMA clt_Investor;
