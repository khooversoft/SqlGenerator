CREATE SCHEMA AssetAcq_pii;
