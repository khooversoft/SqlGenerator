CREATE SCHEMA ing_assetacq;
