CREATE SCHEMA clt_AssetAcq;
