CREATE SCHEMA ctl_Investor;
