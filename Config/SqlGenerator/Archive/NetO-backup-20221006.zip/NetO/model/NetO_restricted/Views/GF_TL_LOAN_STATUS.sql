-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_restricted].[GF_TL_LOAN_STATUS]
AS
   SELECT
      x.[LNUM],
      x.[S_LOAN_STATUS],
      x.[S_UW_STATUS],
      x.[S_LOCK_STATUS],
      x.[LOCK_STATUS_DISPLAY],
      x.[SENT_TO_MIDANET],
      x.[AP_ADMIN_ONLY],
      x.[STATUS_MODIFIED_DT],
      x.[EXT_LOAN_STATUS_VERSION_ID],
      x.[EXT_LOAN_STATUS_VERSION],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TL_LOAN_STATUS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
