-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_restricted].[DTLTRAN]
AS
   SELECT
      x.[LNUM],
      x.[DBID],
      x.[TRANCTR],
      x.[S_TRAN],
      x.[TRANDESC],
      x.[TRANAMT],
      x.[OTHERAMT],
      x.[S_PURCH_CREDIT_TYPE],
      x.[S_PURCH_SOURCE_TYPE],
      x.[OTHERPURCHCREDTYPEDESC],
      x.[OTHERPURCHSRCTYPEDESC],
      x.[MANUALAMT],
      x.[FEEAMT],
      x.[RECORD_CREATED],
      x.[USE_BY_SYSTEM],
      x.[BUILDER_EARNEST_CREDIT],
      x.[EXCLOTHCREDPREP],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[DTLTRAN] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
