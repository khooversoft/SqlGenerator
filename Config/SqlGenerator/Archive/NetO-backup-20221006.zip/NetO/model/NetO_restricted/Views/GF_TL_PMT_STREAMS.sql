-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_restricted].[GF_TL_PMT_STREAMS]
AS
   SELECT
      x.[LNUM],
      x.[PAYMENTCTR],
      x.[NUMPAYMENTS],
      x.[STARTDATE],
      x.[FULLPAYMENT],
      x.[CONSTINTERESTFLAG],
      x.[DEFERODDDAYSFLAG],
      x.[BOUGHTDOWNFLAG],
      x.[INTERESTONLYFLAG],
      x.[MINPMTSTREAMFLAG],
      x.[DISCLOSEDPMT],
      x.[PMI],
      x.[EFFECTIVERATE],
      x.[PAYMENTRATE],
      x.[ADJUSTEDPAYMENT],
      x.[BALANCE],
      x.[PIPAYMENT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TL_PMT_STREAMS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
