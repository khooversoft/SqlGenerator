-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLR_REG_O]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[BOD_APPROVAL],
      x.[O_DATE],
      x.[OFFICER_TITLE],
      x.[NUMBER_OF_SHARES],
      x.[REG_O_BORROWER],
      HASHBYTES('SHA2_256', x.[EMPLOYEE_BORROWER]) AS [EMPLOYEE_BORROWER],
      x.[S_EMP_REGO_TYPE],
      x.[EXEC_EDUC],
      x.[EXEC_OFFIC_OTH],
      x.[EXEC_OFFIC_YN],
      x.[EXEC_FIRST_LIEN],
      x.[BOD_APPROVAL_DATE],
      x.[COMMITTEE_APPROVAL],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLR_REG_O] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
