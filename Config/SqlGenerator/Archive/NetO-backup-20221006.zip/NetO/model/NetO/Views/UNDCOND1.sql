-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[UNDCOND1]
AS
   SELECT
      x.[LNUM],
      x.[S_DISPOSITION],
      x.[S_UWOPT1],
      x.[S_UWOPT2],
      x.[S_UWOPT3],
      x.[S_UWOPT4],
      x.[S_UWOPT5],
      x.[S_UWOPT6],
      x.[INV_APPRV_DATE],
      x.[UNDW_EXP_DATE],
      x.[DOC_EXP_DATE],
      x.[DISPOSITION_DATE],
      x.[CREDSCORE],
      x.[QUALCODE],
      x.[UWCOMDBID],
      x.[UWCOMSN],
      x.[AUSCOMDBID],
      x.[AUSCOMSN],
      x.[S_TRGTINV],
      x.[UWENTITY],
      x.[CREDSCOVRD],
      x.[DELEGATED_ENDORSEMENT],
      x.[UW_INCOME_EXCEPTION_DESC],
      x.[EST_CRED_SCORE],
      x.[CREDIT_REPORT_REF],
      x.[S_CREDSCORE_OVERRIDE_REASON],
      x.[CS_OVR_REAS_OTHERDESC],
      x.[DECISIONTARGETDATE],
      x.[DISPOSITION_DATETIME],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[UNDCOND1] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
