-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[MISC1003]
AS
   SELECT
      x.[LNUM],
      x.[APPNUM],
      x.[OTHINCM],
      x.[COMMUNTY],
      x.[JOINTLY],
      x.[PROF_MERGE_BWRS],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[MISC1003] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
