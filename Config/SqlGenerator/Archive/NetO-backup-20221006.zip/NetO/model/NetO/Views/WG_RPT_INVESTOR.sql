-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_RPT_INVESTOR]
AS
   SELECT
      x.[LNUM],
      x.[MLPSA_KEY],
      x.[PACKAGE_ID],
      x.[TRADECONFIRM_ID],
      x.[FUNDING_ID],
      x.[COUPON_STRIP],
      x.[INVLK_LOCK_PERIOD],
      x.[INVLK_LOCK_PERIOD_DESC],
      x.[PIPELINE_LOCK_ID],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_RPT_INVESTOR] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
