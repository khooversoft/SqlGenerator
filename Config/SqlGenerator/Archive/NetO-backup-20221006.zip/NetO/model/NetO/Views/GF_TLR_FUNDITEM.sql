-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLR_FUNDITEM]
AS
   SELECT
      x.[LNUM],
      x.[TRANS_COUNTER],
      x.[TRANS_DBID],
      x.[SOURCE_XREF],
      x.[MODIFIED_DATE],
      x.[MODIFIED_USER],
      x.[DESCRIPT],
      x.[AMOUNT],
      x.[OMIT_FROM_FUNDING],
      x.[ACTION_TO_TAKE],
      x.[ITEM_STATUS],
      x.[GL_TRANS_CODE],
      x.[BATCHID],
      x.[SOURCE_DISPLAY],
      x.[SRC_FLDNAME],
      x.[SRC_CODE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLR_FUNDITEM] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
