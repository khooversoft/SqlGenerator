-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_COLLATERAL_PLEDGOR]
AS
   SELECT
      x.[LNUM],
      x.[DBID],
      x.[ROWSERIALNO],
      x.[CHILDROWSERIALNO],
      x.[PLEDGOR_TYPE],
      x.[PLEDGOR_MID_NAME],
      x.[PLEDGOR_LAST_NAME],
      x.[PLEDGOR_ENTITY_NAME],
      x.[PLEDGOR_SIGN_CAP],
      x.[PLEDGOR_ENTITY_TTL],
      x.[PLEDGOR_FIRST_NAME],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_COLLATERAL_PLEDGOR] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
