-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[L_SYMBOL]
AS
   SELECT
      x.[FLDNAME],
      x.[DBSYMBOL],
      x.[ALIAS],
      x.[SYMBOLID],
      x.[PROFID],
      x.[DESCRIPT],
      x.[REFCODE],
      x.[CATEGORY],
      x.[MISMO_VALUE],
      x.[SRCENV],
      x.[REC_CUSTOM],
      x.[CREATE_DATE],
      x.[MODIFY_DATE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[L_SYMBOL] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
