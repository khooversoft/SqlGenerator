-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_RPT_INV_LOCK_SNAPSHOT]
AS
   SELECT
      x.[LNUM],
      x.[SNAPSHOTID],
      x.[SNAPSHOT_DATE],
      x.[DELEGATED_ENDORSEMENT_YN],
      x.[PRODUCT],
      x.[RATECODE],
      x.[INTEREST_RATE],
      x.[AMORTIZATION_TYPE],
      x.[INVST_LOCK_PERIOD],
      x.[BASE_MARKET_PRICE],
      x.[TTL_MKT_PRICE_ADJUSTMENTS],
      x.[DELIVERY_TERMS],
      x.[PROPERTY_TYPE],
      x.[DOCUMENTATION_LEVEL],
      x.[OCCUPANCY_TYPE],
      x.[PURP_OF_REFINANCE],
      x.[LOAN_PURPOSE],
      x.[ORIGINAL_LOAN_AMOUNT],
      x.[PROPERTY_LOAN_TO_VALUE],
      x.[COMBINED_LOAN_TO_VALUE],
      x.[ALTERNATE_CREDIT_SCORE],
      x.[PROPERTY_STATE],
      x.[TOTAL_RATIO],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_RPT_INV_LOCK_SNAPSHOT] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
