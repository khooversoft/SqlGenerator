-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_RPT_AMOUNTS]
AS
   SELECT
      x.[LNUM],
      x.[AMORT_TERM],
      x.[APPRAISAL_VALUE],
      x.[CLTV],
      x.[DISCOUNT_AMT],
      x.[HLTV],
      x.[INTEREST_RATE],
      x.[LOCK_DAYS],
      x.[LTV],
      x.[MARGIN_PCT],
      x.[ORIG_LOAN_AMOUNT],
      x.[ORIGINATION_AMT],
      x.[PROP_MKT_VALUE],
      x.[INVLK_MARKET_PRICE],
      x.[INVLK_SRP_FACTOR],
      x.[YSP],
      x.[OVERAGE],
      x.[APR],
      x.[UNPAID_PRIN_BAL],
      x.[ARM_INDEX],
      x.[BASE_MARKET_PRICE],
      x.[BASE_MARKET_PRICE_OVR],
      x.[INVLK_MARKET_PRICE_OVR],
      x.[SERVICING_FEE],
      x.[TTL_MKT_PRICE_ADJUSTMENTS],
      x.[DEBT_RATIO],
      x.[HOUSING_RATIO],
      x.[BASE_LOAN_AMOUNT],
      x.[CONCURRENT_FINANCE_AMT],
      x.[DISCOUNT_POINTS],
      x.[HELOC_INITIAL_ADVANCE],
      x.[QUALIFYING_RATE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_RPT_AMOUNTS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
