-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLBR_RAW_SCORES]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[ROWSERIALNO],
      x.[CREDIT_REPORT_ID],
      x.[CREDIT_REP_SOURCE],
      HASHBYTES('SHA2_256', CAST(x.[CREDIT_SCORE_DATE] AS NVARCHAR(50))) AS [CREDIT_SCORE_DATE],
      x.[CRDT_SC_EXCLU_REASON],
      x.[CRDT_SC_MODEL_NAME],
      x.[MODEL_OTHER_DESC],
      HASHBYTES('SHA2_256', CAST(x.[CREDIT_SCORE_VALUE] AS NVARCHAR(50))) AS [CREDIT_SCORE_VALUE],
      x.[OTHER_SOURCE],
      x.[RANK_PERCENTILE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBR_RAW_SCORES] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
