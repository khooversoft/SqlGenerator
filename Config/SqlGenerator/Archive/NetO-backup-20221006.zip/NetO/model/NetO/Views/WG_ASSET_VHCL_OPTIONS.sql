-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_ASSET_VHCL_OPTIONS]
AS
   SELECT
      x.[LNUM],
      x.[ASSETID],
      x.[ROWCOUNTER],
      x.[VALUATION_CNTR],
      x.[S_OPTION_TYPE],
      x.[VHCL_OPTION_VALUE],
      x.[SELECTED_YN],
      x.[VHCL_OPTION],
      x.[OPTIONS_PRICING_VALUE],
      x.[VHCL_OPTION_PRICE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_ASSET_VHCL_OPTIONS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
