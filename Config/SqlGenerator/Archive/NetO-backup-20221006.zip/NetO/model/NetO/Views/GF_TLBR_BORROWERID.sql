-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLBR_BORROWERID]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[ROWSERIALNO],
      x.[PADBID],
      x.[PASERIALNO],
      x.[IDENTIFICATION_TYPE],
      x.[IDENTIFICATION_DATE],
      x.[IDENTIFICATION_EXP],
      x.[PICTUREID],
      x.[IDENTIFICATION_NUMBER],
      x.[IDENTIFICATION_ORIGIN],
      x.[COUNTRY_DBCODE],
      x.[COUNTRY_CODE_A2],
      x.[BORROWERID_STATE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBR_BORROWERID] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
