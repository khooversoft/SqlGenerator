-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_COLLATERAL_ADDRESS]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[ASSETID],
      x.[ROWSERIALNO],
      x.[COLLATERALADD1],
      x.[COLLATERALADD2],
      x.[COLLATERALCITY],
      x.[COLLATERALSTATE],
      x.[COLLATERALCOUNTY],
      x.[COLLATERALZIP],
      x.[COLLATERALCOUNTRY],
      x.[LANDLORD_PARKNAME],
      x.[PARK_LORTENT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_COLLATERAL_ADDRESS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
