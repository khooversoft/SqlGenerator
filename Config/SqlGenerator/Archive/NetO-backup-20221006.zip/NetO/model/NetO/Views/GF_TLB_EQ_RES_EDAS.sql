-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLB_EQ_RES_EDAS]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[EDAS_SCORE],
      x.[REGION_IND_TEXT],
      x.[REGION_IND_CODE],
      x.[REASON1],
      x.[REASON2],
      x.[REASON3],
      x.[REASON4],
      x.[REJECT_MSG_CODE],
      x.[REASON_TEXT1],
      x.[REASON_TEXT2],
      x.[REASON_TEXT3],
      x.[REASON_TEXT4],
      x.[ENHANCED_DAS_IND],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLB_EQ_RES_EDAS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
