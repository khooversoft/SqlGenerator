-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLB_TU_RES_CRED_SUM]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[REPORTING_PERIOD],
      x.[PUB_REC_NUM],
      x.[COLLECTIONS_NUM],
      x.[NEG_TRADE_NUM],
      x.[HIST_NEG_TRADE_NUM],
      x.[HIST_OCC_NEG_NUM],
      x.[TRADE_NUM],
      x.[REV_CHKCRED_TRD_NUM],
      x.[INSTALL_TRD_NUM],
      x.[MORT_TRD_NUM],
      x.[OPEN_TRADE_NUM],
      x.[INQUIRY_NUM],
      x.[UNSPECIFIEDTRADECOUNT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLB_TU_RES_CRED_SUM] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
