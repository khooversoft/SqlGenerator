-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLRR_FUNDDISB]
AS
   SELECT
      x.[LNUM],
      x.[DISB_DBID],
      x.[DISB_SERNO],
      x.[ORIG_CNTR],
      x.[ORIG_DBID],
      x.[VOIDED_YN],
      x.[PCT_OF_FUNDITEM],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLRR_FUNDDISB] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
