-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLBR_CREDIT]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[ROWSERIALNO],
      HASHBYTES('SHA2_256', CAST(x.[F_SCORE] AS NVARCHAR(50))) AS [F_SCORE],
      HASHBYTES('SHA2_256', CAST(x.[B_SCORE] AS NVARCHAR(50))) AS [B_SCORE],
      x.[E_SCORE],
      x.[C_SCORE],
      HASHBYTES('SHA2_256', CAST(x.[L_SCORE] AS NVARCHAR(50))) AS [L_SCORE],
      x.[MAN_OVERRIDE],
      HASHBYTES('SHA2_256', x.[CREDIT_SOURCE]) AS [CREDIT_SOURCE],
      x.[LINK],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBR_CREDIT] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
