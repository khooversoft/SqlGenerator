-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[WG_RPT_LOAN_CONDITIONS]
AS
   SELECT
      x.[LNUM],
      x.[CNDTN_CNTR],
      x.[CATEGORY],
      x.[CONDITION_TYPE],
      x.[CONDITION_STATE],
      x.[DUE_DATE],
      x.[MAINT_DATE],
      x.[WAIVED_DATE],
      x.[ACTIVE_YN],
      x.[SIGN_OFF_DATE],
      x.[CONDITION],
      x.[UWCONDITION],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_RPT_LOAN_CONDITIONS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
