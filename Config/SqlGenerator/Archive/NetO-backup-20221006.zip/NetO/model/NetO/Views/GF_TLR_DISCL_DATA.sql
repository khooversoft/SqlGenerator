-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO].[GF_TLR_DISCL_DATA]
AS
   SELECT
      x.[LNUM],
      x.[ROWSERIALNO],
      x.[DBID],
      x.[APR],
      x.[FINANCE_CHARGE_AMOUNT],
      x.[FINANCED_AMOUNT],
      x.[TOTAL_PAYMENT_AMOUNT],
      x.[YSP_AMOUNT],
      x.[DISCL_LOAN_AMOUNT],
      x.[DISCL_CLOSING_COSTS],
      x.[DISCL_REVIEW_TILA],
      x.[DISCL_LOAN_TYPE],
      x.[DISCL_PROGRAM],
      x.[DISCL_PAYMENT_STREAM],
      x.[DISCL_MI_PLAN],
      x.[DISCL_OCCUPANCY],
      x.[INT_RATE],
      x.[DISCL_BORROWER_COUNT],
      x.[VERBALDISC],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLR_DISCL_DATA] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
