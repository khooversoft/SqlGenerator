-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLBC_TU_RES_GEOCODE]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[ROWCOUNTER],
      x.[GEO_ZIP_CODE],
      x.[BLOCK_GROUP_STATUS],
      x.[GEO_STATUS],
      x.[CENSUS_TRACK_STATUS],
      x.[SMSA_CODE],
      x.[STATE_CODE],
      x.[COUNTY_CODE],
      x.[CENSUS_TRACK_CODE],
      x.[CENSUS_TRACK_SUFFIX],
      x.[BLOCK_CODE],
      x.[LATITIUDE],
      x.[LONGITUDE],
      x.[ADDRESS_IND],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBC_TU_RES_GEOCODE] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
