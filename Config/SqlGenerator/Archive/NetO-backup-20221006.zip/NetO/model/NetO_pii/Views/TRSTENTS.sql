-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[TRSTENTS]
AS
   SELECT
      x.[LNUM],
      x.[TRUSTNO],
      x.[DBID],
      x.[COUNTER],
      x.[TRFLAG],
      x.[FTRNAME],
      x.[LTRNAME],
      x.[TRSTTYPE],
      x.[TRSTINST],
      x.[MTRNAME],
      x.[TRNAME_SUFFIX],
      x.[POAFLAG],
      x.[POA],
      x.[ADDR],
      x.[CITY],
      x.[STATE],
      x.[ZIP],
      x.[AUTHORIZED_SIGNEE],
      x.[TRSTTL],
      x.[TRUSTPHONE],
      x.[TRUST_FOREIGN_ADDRESS],
      x.[TRUST_FOREIGN_COUNTRY],
      x.[TRUST_STREET_ADDR2],
      x.[EMAIL],
      x.[S_TRUST_UNIT_TYPE],
      x.[TRUST_UNIT_NUM],
      x.[TRUST_COUNTRY_CODE],
      x.[LIVING_TRUST_BNUM],
      x.[TRST_STATE_FOR],
      x.[TRST_POSTCODE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[TRSTENTS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
