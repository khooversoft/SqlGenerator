-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[PREVRES]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[RESCTR],
      x.[RESADD1],
      x.[RESADD2],
      x.[RESCITY],
      x.[RESST],
      x.[RESZIP],
      x.[S_OWNRNT],
      x.[RESNMYRS],
      x.[ACCTPREV],
      x.[ACCTHLDR],
      x.[RESCNTRY],
      x.[LANDCTR],
      x.[RESCNTY],
      x.[RES_FADDR_INDICATOR],
      x.[RECORD_CREATED],
      x.[YRS_AT_PREV],
      x.[MNTHS_AT_PREV],
      x.[S_RES_UNIT_TYPE],
      x.[RES_UNIT_NUM],
      x.[RES_CNTRY_CODE],
      x.[PREV_STATE_FOREIN],
      x.[PREV_POSTCODE],
      x.[S_LIVE_RENT_FREE_ENUMS],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[PREVRES] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
