-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLBC_TU_RES_PUB_REC]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[ROWCOUNTER],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[FILED_DT],
      x.[ASSETS],
      x.[PLAINTIFF],
      x.[INDUSTRY_CODE],
      x.[MEMBER_CODE],
      x.[PR_TYPE],
      x.[DOCKET_NUMBER],
      x.[ATTORNEY],
      x.[REPORTED_DT],
      x.[PAID_DT],
      x.[LIABILITIES_AMOUNT],
      x.[ORIGINAL_BALANCE],
      x.[CURRENT_BALANCE],
      x.[SOURCE_CITY],
      x.[SOURCE_STATE],
      x.[ECOA],
      x.[PR_SOURCE_CODE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBC_TU_RES_PUB_REC] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
