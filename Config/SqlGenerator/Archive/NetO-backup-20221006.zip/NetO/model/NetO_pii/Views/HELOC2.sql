-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[HELOC2]
AS
   SELECT
      x.[LNUM],
      x.[INITIAL_ADVANCE],
      x.[HELOC_DESCRIPTION],
      x.[BILL_END_DATE],
      x.[MIN_BALANCE],
      x.[OPENEND_CREDIT_IND],
      x.[S_RTC_TYPE],
      x.[WAIVE_ANNUAL_FEE],
      x.[ANNUAL_FEE_START_DT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[HELOC2] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
