-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLR_RES_CREDIT_INQUIRY]
AS
   SELECT
      x.[LNUM],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[INQUIRYID],
      x.[DBID],
      x.[PRIMARY_BNUM],
      x.[PRIMARY_DBID],
      x.[SECONDARY_BNUM],
      x.[SECONDARY_DBID],
      x.[NAME],
      x.[ADDRESS1],
      x.[ADDRESS2],
      x.[CITY],
      x.[STATE],
      x.[POSTAL_CODE],
      x.[DATE_OF_INQUIRY],
      x.[INQUIRY_RESULT_TYPE],
      x.[CREDIT_BUSINESS_TYPE],
      x.[CREDIT_LOAN_TYPE],
      x.[TYPE_OTHER_DESC],
      x.[CREDITLIABILITYID],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLR_RES_CREDIT_INQUIRY] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
