-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[SERVICNG]
AS
   SELECT
      x.[LNUM],
      x.[SELLSERV],
      x.[SERVABLE],
      x.[SERVLOAN],
      x.[NSERLOAN],
      x.[NSERLNS3],
      x.[SELLSOME],
      x.[PERTRANS],
      x.[PERCT],
      x.[DOESSELL],
      x.[PREVIOUS],
      x.[YEAR1],
      x.[PERC_YR1],
      x.[YEAR2],
      x.[PERC_YR2],
      x.[YEAR3],
      x.[PERC_YR3],
      x.[INFODOES],
      x.[FORMSTOP],
      x.[NEWSTART],
      x.[AFFCTSN],
      x.[AFFTDBID],
      x.[ACTIONSN],
      x.[ACTNDBID],
      x.[CHNGHOLD],
      x.[CHNGMORT],
      x.[ASSUMPTN],
      x.[TRANSDAT],
      x.[SELRETTR],
      x.[WILTRANS],
      x.[BATCH_ID_SER_NUM],
      x.[SERVICING_TYPE],
      x.[RETAINED_SERVICING_RATE],
      x.[RETAINED_SERVICING_MULTIPLIER],
      x.[RETAINED_SERVICING_VALUE],
      x.[HEDGE_CANDIDATE_YN],
      x.[COUPON_RATE],
      x.[GUARANTEE_FEE],
      x.[DOCS_SENT],
      x.[INDEMNF_AMT],
      x.[PC_FEDEX_NUM],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[SERVICNG] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
