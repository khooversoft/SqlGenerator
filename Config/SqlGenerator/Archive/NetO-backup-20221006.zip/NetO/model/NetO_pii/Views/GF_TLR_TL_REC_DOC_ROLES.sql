-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLR_TL_REC_DOC_ROLES]
AS
   SELECT
      x.[LNUM],
      x.[RESPONSEID],
      x.[TITLERESPONSEID],
      x.[DBID],
      x.[RECDOCID],
      x.[RECDOCEXTID],
      x.[EXTITEMSID],
      x.[FIRSTNAME],
      x.[LASTNAME],
      x.[VESTINGINFO],
      x.[COMMENTS],
      x.[UNPARSEDNAME],
      x.[EXTTYPE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLR_TL_REC_DOC_ROLES] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
