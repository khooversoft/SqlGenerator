-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[TRANSDATA]
AS
   SELECT
      x.[LNUM],
      x.[PURPRICE],
      x.[IMPCOST],
      x.[COSTLAND],
      x.[REFAMT],
      x.[ESTPREPD],
      x.[ESTCLOS],
      x.[MIFUND],
      x.[DISCOUNT],
      x.[SUBFIN],
      x.[SELLCLOS],
      x.[FINFEES],
      x.[LOANONLY],
      x.[SUB_BELOW_MARKET],
      x.[SUBORDINATE_TOTAL],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[TRANSDATA] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
