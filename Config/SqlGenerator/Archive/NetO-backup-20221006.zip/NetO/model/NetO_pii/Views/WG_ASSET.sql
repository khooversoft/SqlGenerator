-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[WG_ASSET]
AS
   SELECT
      x.[LNUM],
      x.[ASSETID],
      x.[S_ASSET_TYPE],
      x.[S_ASSET_PURPOSE],
      x.[ASSET_VERIFIED],
      x.[VERIFICATION_REQD],
      x.[OWNER_EST_VALUE],
      x.[ACTUAL_VALUE],
      x.[SALES_PRICE],
      x.[ASSET_DESC],
      x.[DISCOUNT_PCT],
      x.[SALES_PRICE_VALUE],
      x.[DISCOUNT_PCTOVD],
      x.[PRIMARY_COLLATERAL],
      x.[RECORD_CREATED],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_ASSET] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
