-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[WG_RPT_LOAN_REMARKS]
AS
   SELECT
      x.[LNUM],
      x.[RMKID],
      x.[ENTERED_DATE],
      x.[USRID],
      x.[USERNAME],
      x.[REMARK_TYPE],
      x.[ACTIVITY],
      x.[TASK],
      x.[REMARK],
      x.[REMARKS_TXT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_RPT_LOAN_REMARKS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
