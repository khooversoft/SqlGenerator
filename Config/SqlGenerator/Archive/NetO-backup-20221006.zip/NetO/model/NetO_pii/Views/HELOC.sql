-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[HELOC]
AS
   SELECT
      x.[LNUM],
      x.[INTRORT],
      x.[MINITADV],
      x.[MOTHADV],
      x.[DPR],
      x.[DRAWPER],
      x.[WHENDUE],
      x.[TAXLTV],
      x.[SLNHOLD],
      x.[DRAWEXP],
      x.[TAXASAMT],
      x.[CTAXLTV],
      x.[NUM_CARDS],
      x.[S_LOCTYPE],
      x.[ANNUAL_FEE],
      x.[REPAY_MTHS],
      x.[TERMIN_FEE],
      x.[DRAWACCESS_FEE],
      x.[S_FUNDS_TO_BE_DRAWN],
      x.[OVERDRAFT_PROTECTION],
      x.[ODP_ACCOUNT_NUMBER],
      x.[ODP_ROUTING_NUMBER],
      x.[ANNUAL_CALC_OVR],
      x.[TERM_CALC_OVR],
      x.[S_REPAYMENT_METHOD],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[HELOC] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
