-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[FLOOD]
AS
   SELECT
      x.[LNUM],
      x.[INSREQ],
      x.[FLDZNCRT],
      x.[LIFELOAN],
      x.[DETMNNUM],
      x.[DETMNDAT],
      x.[S_FIRM],
      x.[S_FLDZON],
      x.[FLDMAPDT],
      x.[COMMNUMB],
      x.[SFHAREA],
      x.[NOTMAPD],
      x.[OBTNINS],
      x.[NOTFLOOD],
      x.[MAPNUMB],
      x.[NFIP_MAP_PANEL_DATE],
      x.[COMMNAME],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[FLOOD] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
