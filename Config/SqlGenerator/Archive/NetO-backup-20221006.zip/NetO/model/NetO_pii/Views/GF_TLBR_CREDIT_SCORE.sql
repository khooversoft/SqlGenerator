-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLBR_CREDIT_SCORE]
AS
   SELECT
      x.[LNUM],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[SCOREID],
      x.[DBID],
      x.[BORROWER_ID],
      x.[BNUM],
      x.[SOURCE_TYPE],
      x.[SCORE_DATE],
      x.[REASON_TYPE],
      x.[MODEL_TYPE],
      x.[OTHER_DESCRIPTION],
      x.[SCORE_VALUE],
      x.[CREDREPOSSRCTYPEOTHERDESC],
      x.[FACTAINQUIRIESINDICATOR],
      x.[RANK_PERCENTILE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLBR_CREDIT_SCORE] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
