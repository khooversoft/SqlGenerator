-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[DENIAL]
AS
   SELECT
      x.[LNUM],
      x.[APPRGUIDE],
      x.[APPRINCON],
      x.[APPRCOMP],
      x.[APPRUNACC],
      x.[APPRRATIO],
      x.[APPROTHR],
      x.[APPRREASN],
      x.[CRDHISTRY],
      x.[BANKRPTCY],
      x.[PYMTPRES],
      x.[PYMTPREV],
      x.[CRDEXPLAN],
      x.[NONCRD],
      x.[OBLIGATN],
      x.[CRDOTHR],
      x.[CRDREASN],
      x.[IRREGEMP],
      x.[ESTINC],
      x.[STABLEINC],
      x.[EMPOTHR],
      x.[EMPREASN],
      x.[LIQASST],
      x.[CASH],
      x.[SECFINC],
      x.[ASSTOTHR],
      x.[ASSTREASN],
      x.[INCINSUF1],
      x.[INCINSUF2],
      x.[SHORTINC],
      x.[EXCESSRAT],
      x.[QUALOTHR],
      x.[QUALREASN],
      x.[APPLINCMP],
      x.[OTHER],
      x.[OTHERREASN],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[DENIAL] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
