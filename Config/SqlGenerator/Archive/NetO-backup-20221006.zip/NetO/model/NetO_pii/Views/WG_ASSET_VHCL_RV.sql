-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[WG_ASSET_VHCL_RV]
AS
   SELECT
      x.[LNUM],
      x.[ASSETID],
      x.[S_RV_TYPE],
      x.[MILEAGE],
      x.[NBR_AXLES],
      x.[NBR_SLIDES],
      x.[RV_LENGTH],
      x.[SELF_CONTAINED_YN],
      x.[S_CATEGORY],
      x.[S_MODEL_TYPE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_ASSET_VHCL_RV] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
