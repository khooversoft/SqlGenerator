-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLB_EX_RES_TRENDS_SUM]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[RESPONSEID],
      x.[CREDITRESPONSEID],
      x.[VARIATION_IND],
      x.[MONTH_IND],
      x.[REVOLVE_BAL_TTL],
      x.[REVOLVE_BAL_AVG],
      x.[PERCENT_UTILIZED],
      x.[BANK_NAT_CARDS],
      x.[RETAIL_CARDS],
      x.[CARD_WITH_BALANCE],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLB_EX_RES_TRENDS_SUM] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
