-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLB_HOUSING_PRSNT]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[GROUND_RENT_AMT],
      x.[HAZARD_INS_AMT],
      x.[HOA_DUES_AMT],
      x.[LEASEHOLD_PMT_AMT],
      x.[MAINT_MISC_AMT],
      x.[MI_AMT],
      x.[MTG_PITI_AMT],
      x.[MTG_PRIN_INT_AMT],
      x.[OTHER_HOUSING_AMT],
      x.[OTHER_MTG_PITI_AMT],
      x.[OTHER_MTG_PRIN_INT_AMT],
      x.[REAL_ESTATE_TAX_AMT],
      x.[RENT_AMT],
      x.[UTILITIES_AMT],
      x.[OTHER_EXP_TOTAL],
      x.[FLOOD_INS_AMT],
      x.[ASSESSMENT_AMT],
      x.[WATER_PURI_AMT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLB_HOUSING_PRSNT] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
