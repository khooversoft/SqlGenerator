-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[INFO1008]
AS
   SELECT
      x.[LNUM],
      x.[BASEINC],
      x.[OTHERINC],
      x.[POSINC],
      x.[C_BASEINC],
      x.[C_OTHERINC],
      x.[C_POSINC],
      x.[TBASEINC],
      x.[TOTHERINC],
      x.[TPOSINC],
      x.[TBORINC],
      x.[TCBORINC],
      x.[ALLINC],
      x.[FIRSTMORT],
      x.[SECMORT],
      x.[HAZINS],
      x.[TAXES],
      x.[MORTINS],
      x.[ASSDUES],
      x.[LEASE],
      x.[OTHEREXP],
      x.[THOUSEXP],
      x.[NEGCASH],
      x.[OTHERMTHY],
      x.[ALLPMT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[INFO1008] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
