-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[UNDCOND2]
AS
   SELECT
      x.[LNUM],
      x.[DBID],
      x.[CNTR],
      x.[S_SUNDCON],
      x.[S_UNDCAT],
      x.[S_UNDTYP],
      x.[CUUSRID],
      x.[CUUSGRP],
      x.[CUDATE],
      x.[CUSTATE],
      x.[SIGNDT],
      x.[WAIVEDDT],
      x.[LOANTYPE],
      x.[UWCKLIST],
      x.[ISACTIVE],
      x.[S_ASSOCDOC],
      x.[SHWWAIVE],
      x.[DISCLOSE],
      x.[S_COMFLG],
      x.[RESPONSIBLE_P],
      x.[DUEDATE],
      x.[ERRORCAUSEBY],
      x.[S_CONDITION_SRC],
      x.[CREATED_DATE],
      x.[CREATED_USER],
      x.[RECEIVED_DT],
      x.[IMGSTATUS],
      x.[REVIEWED_DT],
      x.[WAIVE_REASON_TEXT],
      x.[CONDITION_TEXT],
      x.[PUBLISHED],
      x.[REASON_ADD_COND],
      x.[REJECTED_DT],
      x.[RESET_DT],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[UNDCOND2] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
