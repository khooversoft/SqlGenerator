-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[BORDEP]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[AGES],
      x.[AGENCY],
      x.[CONTACT],
      x.[COST],
      x.[PAYFLAG],
      x.[NOPYDBID],
      x.[NOPAYSN],
      x.[AGYADD1],
      x.[AGYADD2],
      x.[AGYCITY],
      x.[AGYSTATE],
      x.[AGYZIP],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[BORDEP] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
