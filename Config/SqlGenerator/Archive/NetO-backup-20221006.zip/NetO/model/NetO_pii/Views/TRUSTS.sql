-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[TRUSTS]
AS
   SELECT
      x.[LNUM],
      x.[TRUSTCNT],
      x.[TRSTDBID],
      x.[TRSTSERI],
      x.[TRSTNAME],
      x.[TRSTDATE],
      x.[TRSTTXID],
      x.[TRSTADT1],
      x.[TRSTADT2],
      x.[TRSTNUMB],
      x.[S_TRSTYP],
      x.[TRSTINST],
      x.[TRSTREV],
      x.[STATE],
      x.[TRSTNOMINEE],
      x.[IDENTIFICATION_NUM],
      x.[QPRT_IND],
      x.[QPRT_EXP_DATE],
      x.[QPRT_BEN_WAIVER],
      x.[LIVTRST],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[TRUSTS] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
