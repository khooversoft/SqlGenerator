-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[GF_TLB_MAILING]
AS
   SELECT
      x.[LNUM],
      x.[BNUM],
      x.[DBID],
      x.[MAILADDR1],
      x.[MAILADDR2],
      x.[MAILCITY],
      x.[MAILSTATE],
      x.[MAILCNTY],
      x.[MAILZIP],
      x.[MAILCOUNTRY],
      x.[MAIL_FADDR_INDICATOR],
      x.[S_MAIL_UNIT_TYPE],
      x.[MAIL_UNIT_NUM],
      x.[MAIL_COUNTRY_CODE],
      x.[BOR_MAIL_STATE_FOREIN],
      x.[MAIL_POST_CODE_FOREIN],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[GF_TLB_MAILING] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
