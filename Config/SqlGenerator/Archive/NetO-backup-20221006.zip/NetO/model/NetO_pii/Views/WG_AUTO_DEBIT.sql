-- -----------------------------------------------------
-- Auto generated
-- -----------------------------------------------------


CREATE VIEW [NetO_pii].[WG_AUTO_DEBIT]
AS
   SELECT
      x.[LNUM],
      x.[AD_FLAG],
      x.[S_AD_ACCT_TYPE],
      x.[AD_INST_NAME],
      x.[AD_ACCT_NUMB],
      x.[AD_RT_NUMB],
      x.[AD_DAYOFAD],
      x.[AD_ADDL_PRINC],
      x.[AD_ACCT_TYP_OTH],
      x.[ASAP_ROW_HASH],
      x.[ASAP_DML_FLAG],
      x.[ASAP_CREATED_DATE],
      x.[ASAP_UPDATED_DATE],
      x.[ASAP_LINEAGE_ID],
      x.[ASAP_ACTIVITY_ID],
      x.[ASAP_TRIGGER_ID],
      x.[ASAP_SRC_FILEPATH],
      x.[ASAP_SRC_FILE_DATE],
      x.[ASAP_SRC_NAME]
   FROM [clt_NetO].[WG_AUTO_DEBIT] x
   WHERE x.[ASAP_DeleteDateTime] IS NULL
;
