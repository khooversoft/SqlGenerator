

DECLARE @env AS NVARCHAR(16) = (SELECT @@SERVERNAME)
DECLARE @src_storage_acct NVARCHAR(256)

IF @env = 'asapcoretest'
BEGIN	
 SET @src_storage_acct = 'https://asapadlstest.blob.core.windows.net'
END
ELSE IF @env = 'asapcorepp'
BEGIN	
 SET @src_storage_acct = 'https://asapadlspp.blob.core.windows.net'
END
ELSE IF  @env = 'asapcore'
BEGIN	
 SET @src_storage_acct = 'https://asapadls.blob.core.windows.net'
END


PRINT CONCAT('@env:',@env)
PRINT CONCAT('@src_storage_acct',@src_storage_acct)


/*****************************************************
--Global Metadata
******************************************************/
DECLARE @pipeline_name AS NVARCHAR(260) = N'pl_Neto_raw_to_cultivated_copyinto';
DECLARE @activity_name AS NVARCHAR(260) = N'cp_extract_to_raw';

/*****************************************************
--Pipeline Metadata
******************************************************/
DROP TABLE IF EXISTS #pipeline;

SELECT TOP 1 pipeline_name, trigger_type INTO #pipeline FROM cntrl.pipeline;

TRUNCATE TABLE #pipeline;

INSERT INTO #pipeline (pipeline_name, trigger_type) VALUES (@pipeline_name, 'scheduled_daily');

PRINT 'Merge Pipeline';

MERGE cntrl.pipeline tgt
USING #pipeline src
ON tgt.pipeline_name = src.pipeline_name
   AND tgt.trigger_type = src.trigger_type
WHEN NOT MATCHED THEN INSERT (pipeline_name, trigger_type)
                      VALUES
                      (src.pipeline_name, src.trigger_type);

/*****************************************************
--Activity Metadata
******************************************************/
DROP TABLE IF EXISTS #activity;

SELECT TOP 1
       activity_name,
       pipeline_id,
       pipeline_name,
       activity_type,
       step_number,
       is_rerunnable,
       retry,
       retry_interval,
       activity_timeout
INTO
 #activity
FROM
 cntrl.activity;

DECLARE @pipeline_id BIGINT = (SELECT pipeline_id FROM cntrl.pipeline WHERE pipeline_name = @pipeline_name);

TRUNCATE TABLE #activity;

INSERT INTO #activity (activity_name, pipeline_id, pipeline_name, activity_type, step_number, is_rerunnable, retry, retry_interval, activity_timeout)
VALUES
(@activity_name, @pipeline_id, @pipeline_name, 'copy_query', 1, 1, 3, 5, 1800);

PRINT 'Merge Activity';

MERGE cntrl.activity tgt
USING #activity src
ON tgt.activity_name = src.activity_name
   AND tgt.pipeline_id = src.pipeline_id
   AND tgt.pipeline_name = src.pipeline_name
   AND tgt.activity_type = src.activity_type
WHEN MATCHED AND (
              ISNULL(tgt.pipeline_name, '0') <> ISNULL(src.pipeline_name, '0')
              OR ISNULL(tgt.activity_type, '0') <> ISNULL(src.activity_type, '0')
              OR ISNULL(tgt.step_number, '0') <> ISNULL(src.step_number, '0')
              OR ISNULL(tgt.is_rerunnable, '0') <> ISNULL(src.is_rerunnable, '0')
              OR ISNULL(tgt.retry, '0') <> ISNULL(src.retry, '0')
              OR ISNULL(tgt.retry_interval, '0') <> ISNULL(src.retry_interval, '0')
              OR ISNULL(tgt.activity_timeout, '0') <> ISNULL(src.activity_timeout, '0')
             ) THEN UPDATE SET
                     tgt.activity_name = src.activity_name,
                     tgt.pipeline_id = src.pipeline_id,
                     tgt.pipeline_name = src.pipeline_name,
                     tgt.activity_type = src.activity_type,
                     tgt.step_number = src.step_number,
                     tgt.is_rerunnable = src.is_rerunnable,
                     tgt.retry = src.retry,
                     tgt.retry_interval = src.retry_interval,
                     tgt.activity_timeout = src.activity_timeout,
                     tgt.update_dttm = GETUTCDATE(),
                     tgt.updated_by = SUSER_SNAME()
WHEN NOT MATCHED THEN INSERT (activity_name, pipeline_id, pipeline_name, activity_type, step_number, is_rerunnable, retry, retry_interval, activity_timeout)
                      VALUES
                      (src.activity_name, src.pipeline_id, src.pipeline_name, src.activity_type, src.step_number, src.is_rerunnable, src.retry, src.retry_interval, src.activity_timeout);

/*****************************************************
--Activity Parameters
******************************************************/
DROP TABLE IF EXISTS #activity_parameter;

SELECT TOP 1
       activity_id,
       activity_name,
       activity_type,
       context,
       param_name,
       param_value
INTO
 #activity_parameter
FROM
 cntrl.activity_parameter;

DECLARE @activity_id BIGINT = (SELECT activity_id FROM cntrl.activity WHERE activity_name = @activity_name AND pipeline_id = @pipeline_id);

TRUNCATE TABLE #activity_parameter;

INSERT INTO #activity_parameter (activity_id, activity_name, activity_type, context, param_name, param_value)
VALUES
--Source											
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_linked_service', 'ls_sql_server'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'subject_area', 'copycmd'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'query_timeout', '120'),         --Default '120'
                                                                                      --file options
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'file_compression', 'None'),     --gzip, None, snappy, zip, tar
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'compression_level', 'Optimal'), --Fastest, Optimal
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'field_terminator', '||'),        --| or ,
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'row_terminator', '\n'),       --
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'field_quote', '"'),             --"
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'encoding', 'UTF-8'),            --
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'max_errors', '10'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'file_type', 'csv'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'first_row', '2'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_storage_acct',  @src_storage_acct),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_container', 'raw'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_directory', 'Neto'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_filepath_pattern', 'yyyy/MM/dd'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'src_file_type', 'csv'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'error_file_container', 'raw'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'skip_line_count', '1'),                                                                                      
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'ingest_schema', 'ing_Neto'),          
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'cultivated_schema_name', 'clt_Neto'),          
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'latest_version_orderby_mapping', 'ASAP_SRC_FILEPATH'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'ASAP_RecordEffectiveDateTime_mapping', 'ASAP_SRC_FILE_DATE'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'tgt_linked_service', 'asap_syn'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'parent_key', 'LNUM'),
(@activity_id, @activity_name, 'copy_cmd', 'Source', 'date_from_format', 'YYYYMMDD_HHMMSS');

PRINT 'Merge Activity Parameter';

MERGE cntrl.activity_parameter tgt
USING #activity_parameter src
ON tgt.activity_id = src.activity_id
   AND tgt.activity_name = src.activity_name
   AND tgt.activity_type = src.activity_type
   AND tgt.context = src.context
   AND tgt.param_name = src.param_name
WHEN MATCHED AND ISNULL(tgt.param_value, '0') <> ISNULL(src.param_value, '0') THEN UPDATE SET
                                                                                    tgt.param_value = src.param_value,
                                                                                    tgt.update_dttm = GETUTCDATE(),
                                                                                    tgt.updated_by = SUSER_SNAME()
WHEN NOT MATCHED THEN INSERT (activity_id, activity_name, activity_type, context, param_name, param_value)
                      VALUES
                      (src.activity_id, src.activity_name, src.activity_type, src.context, src.param_name, src.param_value);

/*****************************************************
--Data Object Parameters
******************************************************/
DROP TABLE IF EXISTS #data_object_parameter;

SELECT TOP 1
       data_object_name,
       activity_id,
       activity_name,
       is_enabled,
       context,
       param_name,
       param_value,
       execution_type
INTO
 #data_object_parameter
FROM
 cntrl.data_object_parameter;


TRUNCATE TABLE #data_object_parameter;

INSERT INTO #data_object_parameter (data_object_name, activity_id, activity_name, is_enabled, context, param_name, param_value, execution_type)
VALUES

--Query Option 3: Lookup Column, generated in copy parameter
/************copy_into_test************/

('ADV_ACTN', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_ADV_ACTN_20', 0),
('ADV_ACTN', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('ADV_ACTN', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('APPREQ', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_APPREQ_20', 0),
('APPREQ', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('APPREQ', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('ARMINFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_ARMINFO_20', 0),
('ARMINFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('ARMINFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('ASSETS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_ASSETS_20', 0),
('ASSETS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('ASSETS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('BORDEP', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_BORDEP_20', 0),
('BORDEP', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('BORDEP', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('BORROWER', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_BORROWER_20', 0),
('BORROWER', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('BORROWER', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('CONSREFI', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_CONSREFI_20', 0),
('CONSREFI', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('CONSREFI', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DATES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DATES_20', 0),
('DATES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DATES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DECLRTN', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DECLRTN_20', 0),
('DECLRTN', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DECLRTN', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DELIVERY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DELIVERY_20', 0),
('DELIVERY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DELIVERY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DENIAL', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DENIAL_20', 0),
('DENIAL', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DENIAL', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DOWNPYMT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DOWNPYMT_20', 0),
('DOWNPYMT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DOWNPYMT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('DTLTRAN', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_DTLTRAN_20', 0),
('DTLTRAN', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('DTLTRAN', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('FEEVALS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_FEEVALS_20', 0),
('FEEVALS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('FEEVALS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('FLOOD', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_FLOOD_20', 0),
('FLOOD', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('FLOOD', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_DATES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_DATES_20', 0),
('GF_TL_DATES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_DATES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_DATES3', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_DATES3_20', 0),
('GF_TL_DATES3', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_DATES3', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_HOUSING_PROPSD', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_HOUSING_PROPSD_20', 0),
('GF_TL_HOUSING_PROPSD', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_HOUSING_PROPSD', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_LOAN_CONTACTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_LOAN_CONTACTS_20', 0),
('GF_TL_LOAN_CONTACTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_LOAN_CONTACTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_LOAN_CONTACTS2', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_LOAN_CONTACTS2_20', 0),
('GF_TL_LOAN_CONTACTS2', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_LOAN_CONTACTS2', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_LOAN_DATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_LOAN_DATA_20', 0),
('GF_TL_LOAN_DATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_LOAN_DATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_LOAN_STATUS_20', 0),
('GF_TL_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_MISC_CK', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_MISC_CK_20', 0),
('GF_TL_MISC_CK', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_MISC_CK', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_PMT_STREAMS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_PMT_STREAMS_20', 0),
('GF_TL_PMT_STREAMS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_PMT_STREAMS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_PNP_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_PNP_IPG_DETAIL_20', 0),
('GF_TL_PNP_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_PNP_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_POINT_OF_SALE_INFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_POINT_OF_SALE_INFO_20', 0),
('GF_TL_POINT_OF_SALE_INFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_POINT_OF_SALE_INFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_TRANSOVR', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_TRANSOVR_20', 0),
('GF_TL_TRANSOVR', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_TRANSOVR', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_UW_4', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_UW_4_20', 0),
('GF_TL_UW_4', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_UW_4', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TL_UWAPPREXT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TL_UWAPPREXT_20', 0),
('GF_TL_UWAPPREXT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TL_UWAPPREXT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLB_EQ_RES_EDAS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLB_EQ_RES_EDAS_20', 0),
('GF_TLB_EQ_RES_EDAS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLB_EQ_RES_EDAS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLB_EX_RES_TRENDS_SUM', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLB_EX_RES_TRENDS_SUM_20', 0),
('GF_TLB_EX_RES_TRENDS_SUM', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLB_EX_RES_TRENDS_SUM', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLB_HOUSING_PRSNT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLB_HOUSING_PRSNT_20', 0),
('GF_TLB_HOUSING_PRSNT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLB_HOUSING_PRSNT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLB_MAILING', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLB_MAILING_20', 0),
('GF_TLB_MAILING', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLB_MAILING', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLB_TU_RES_CRED_SUM', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLB_TU_RES_CRED_SUM_20', 0),
('GF_TLB_TU_RES_CRED_SUM', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLB_TU_RES_CRED_SUM', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBC_EQ_RES_COLLECT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBC_EQ_RES_COLLECT_20', 0),
('GF_TLBC_EQ_RES_COLLECT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBC_EQ_RES_COLLECT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBC_TU_RES_GEOCODE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBC_TU_RES_GEOCODE_20', 0),
('GF_TLBC_TU_RES_GEOCODE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBC_TU_RES_GEOCODE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBC_TU_RES_PUB_REC', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBC_TU_RES_PUB_REC_20', 0),
('GF_TLBC_TU_RES_PUB_REC', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBC_TU_RES_PUB_REC', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBC_TU_RES_TRADELINE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBC_TU_RES_TRADELINE_20', 0),
('GF_TLBC_TU_RES_TRADELINE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBC_TU_RES_TRADELINE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_ADDITIONALDATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_ADDITIONALDATA_20', 0),
('GF_TLBR_ADDITIONALDATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_ADDITIONALDATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_ALIAS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_ALIAS_20', 0),
('GF_TLBR_ALIAS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_ALIAS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_ASSIST_PROGRAMS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_ASSIST_PROGRAMS_20', 0),
('GF_TLBR_ASSIST_PROGRAMS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_ASSIST_PROGRAMS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_BORROWERID', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_BORROWERID_20', 0),
('GF_TLBR_BORROWERID', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_BORROWERID', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_CREDIT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_CREDIT_20', 0),
('GF_TLBR_CREDIT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_CREDIT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_CREDIT_SCORE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_CREDIT_SCORE_20', 0),
('GF_TLBR_CREDIT_SCORE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_CREDIT_SCORE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_DEPENDENTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_DEPENDENTS_20', 0),
('GF_TLBR_DEPENDENTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_DEPENDENTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_EMPLOYER', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_EMPLOYER_20', 0),
('GF_TLBR_EMPLOYER', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_EMPLOYER', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_ETHNICITY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_ETHNICITY_20', 0),
('GF_TLBR_ETHNICITY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_ETHNICITY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_HOUSNG_PRSNT_OTH', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_HOUSNG_PRSNT_OTH_20', 0),
('GF_TLBR_HOUSNG_PRSNT_OTH', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_HOUSNG_PRSNT_OTH', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_RACE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_RACE_20', 0),
('GF_TLBR_RACE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_RACE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_RAW_SCORES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_RAW_SCORES_20', 0),
('GF_TLBR_RAW_SCORES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_RAW_SCORES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_SUBETHNICITY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_SUBETHNICITY_20', 0),
('GF_TLBR_SUBETHNICITY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_SUBETHNICITY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLBR_SUBRACE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLBR_SUBRACE_20', 0),
('GF_TLBR_SUBRACE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLBR_SUBRACE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_DISBURSEMENTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_DISBURSEMENTS_20', 0),
('GF_TLR_DISBURSEMENTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_DISBURSEMENTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_DISCL_DATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_DISCL_DATA_20', 0),
('GF_TLR_DISCL_DATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_DISCL_DATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_FLOOD_DETMN', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_FLOOD_DETMN_20', 0),
('GF_TLR_FLOOD_DETMN', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_FLOOD_DETMN', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_FUNDITEM', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_FUNDITEM_20', 0),
('GF_TLR_FUNDITEM', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_FUNDITEM', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_INSURANCE_20', 0),
('GF_TLR_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_REG_O', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_REG_O_20', 0),
('GF_TLR_REG_O', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_REG_O', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_REOWNED_BORROWERS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_REOWNED_BORROWERS_20', 0),
('GF_TLR_REOWNED_BORROWERS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_REOWNED_BORROWERS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_REQ_CREDIT_LIAB_REP', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_REQ_CREDIT_LIAB_REP_20', 0),
('GF_TLR_REQ_CREDIT_LIAB_REP', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_REQ_CREDIT_LIAB_REP', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_REQ_NADA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_REQ_NADA_20', 0),
('GF_TLR_REQ_NADA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_REQ_NADA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RES_CREDIT_FILE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RES_CREDIT_FILE_20', 0),
('GF_TLR_RES_CREDIT_FILE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RES_CREDIT_FILE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RES_CREDIT_INQUIRY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RES_CREDIT_INQUIRY_20', 0),
('GF_TLR_RES_CREDIT_INQUIRY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RES_CREDIT_INQUIRY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RES_CREDIT_LIABILITY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RES_CREDIT_LIABILITY_20', 0),
('GF_TLR_RES_CREDIT_LIABILITY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RES_CREDIT_LIABILITY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RES_CREDIT_SUMMARY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RES_CREDIT_SUMMARY_20', 0),
('GF_TLR_RES_CREDIT_SUMMARY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RES_CREDIT_SUMMARY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RES_NADA_VAL', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RES_NADA_VAL_20', 0),
('GF_TLR_RES_NADA_VAL', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RES_NADA_VAL', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_RSP_LP_LOANFDBCK', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_RSP_LP_LOANFDBCK_20', 0),
('GF_TLR_RSP_LP_LOANFDBCK', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_RSP_LP_LOANFDBCK', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_SUBJPRP_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_SUBJPRP_INSURANCE_20', 0),
('GF_TLR_SUBJPRP_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_SUBJPRP_INSURANCE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_SUBJPRP_TAX', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_SUBJPRP_TAX_20', 0),
('GF_TLR_SUBJPRP_TAX', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_SUBJPRP_TAX', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_TAXITEMS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_TAXITEMS_20', 0),
('GF_TLR_TAXITEMS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_TAXITEMS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLR_TL_REC_DOC_ROLES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLR_TL_REC_DOC_ROLES_20', 0),
('GF_TLR_TL_REC_DOC_ROLES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLR_TL_REC_DOC_ROLES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TLRR_FUNDDISB', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TLRR_FUNDDISB_20', 0),
('GF_TLRR_FUNDDISB', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('GF_TLRR_FUNDDISB', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('GF_TS_AUDIT_LOAN_DELETE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_GF_TS_AUDIT_LOAN_DELETE_20', 1),
('GF_TS_AUDIT_LOAN_DELETE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 1),
('GF_TS_AUDIT_LOAN_DELETE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 1),
('HELOC', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_HELOC_20', 0),
('HELOC', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('HELOC', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('HELOC2', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_HELOC2_20', 0),
('HELOC2', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('HELOC2', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('HMDAINFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_HMDAINFO_20', 0),
('HMDAINFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('HMDAINFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('INCOME', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_INCOME_20', 0),
('INCOME', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('INCOME', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('INFO1008', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_INFO1008_20', 0),
('INFO1008', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('INFO1008', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('L_SYMBOL', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_L_SYMBOL_20', 1),
('L_SYMBOL', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 1),
('L_SYMBOL', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 1),
('LIABLTY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_LIABLTY_20', 0),
('LIABLTY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('LIABLTY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('MISC1003', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_MISC1003_20', 0),
('MISC1003', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('MISC1003', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('POA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_POA_20', 0),
('POA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('POA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('PREDCTRS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_PREDCTRS_20', 0),
('PREDCTRS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('PREDCTRS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('PREVRES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_PREVRES_20', 0),
('PREVRES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('PREVRES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('PRODUCT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_PRODUCT_20', 0),
('PRODUCT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('PRODUCT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('PRTFOLIO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_PRTFOLIO_20', 0),
('PRTFOLIO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('PRTFOLIO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('REOWNED', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_REOWNED_20', 0),
('REOWNED', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('REOWNED', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('SEIA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_SEIA_20', 0),
('SEIA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('SEIA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('SELLER', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_SELLER_20', 0),
('SELLER', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('SELLER', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('SERVICNG', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_SERVICNG_20', 0),
('SERVICNG', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('SERVICNG', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('SUBJPRP', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_SUBJPRP_20', 0),
('SUBJPRP', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('SUBJPRP', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TAXINFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TAXINFO_20', 0),
('TAXINFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TAXINFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TILINFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TILINFO_20', 0),
('TILINFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TILINFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TRACKING', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TRACKING_20', 0),
('TRACKING', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TRACKING', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TRANSDATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TRANSDATA_20', 0),
('TRANSDATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TRANSDATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TRSTENTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TRSTENTS_20', 0),
('TRSTENTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TRSTENTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('TRUSTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_TRUSTS_20', 0),
('TRUSTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('TRUSTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('UNDCOND1', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_UNDCOND1_20', 0),
('UNDCOND1', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('UNDCOND1', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('UNDCOND2', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_UNDCOND2_20', 0),
('UNDCOND2', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('UNDCOND2', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('UWAPPR', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_UWAPPR_20', 0),
('UWAPPR', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('UWAPPR', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('VARTXT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_VARTXT_20', 0),
('VARTXT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('VARTXT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('VETINFO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_VETINFO_20', 0),
('VETINFO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('VETINFO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_20', 0),
('WG_ASSET', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_ACCT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_ACCT_20', 0),
('WG_ASSET_ACCT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_ACCT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_MARINE_ENG', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_MARINE_ENG_20', 0),
('WG_ASSET_MARINE_ENG', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_MARINE_ENG', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VEHICLE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VEHICLE_20', 0),
('WG_ASSET_VEHICLE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VEHICLE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_AUTO', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_AUTO_20', 0),
('WG_ASSET_VHCL_AUTO', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_AUTO', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_MARINE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_MARINE_20', 0),
('WG_ASSET_VHCL_MARINE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_MARINE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_OPTIONS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_OPTIONS_20', 0),
('WG_ASSET_VHCL_OPTIONS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_OPTIONS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_RV', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_RV_20', 0),
('WG_ASSET_VHCL_RV', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_RV', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_TRAILER', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_TRAILER_20', 0),
('WG_ASSET_VHCL_TRAILER', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_TRAILER', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_ASSET_VHCL_VALUATION', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_ASSET_VHCL_VALUATION_20', 0),
('WG_ASSET_VHCL_VALUATION', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_ASSET_VHCL_VALUATION', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_AUTO_DEBIT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_AUTO_DEBIT_20', 0),
('WG_AUTO_DEBIT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_AUTO_DEBIT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_BULK_IMPORT_DATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_BULK_IMPORT_DATA_20', 0),
('WG_BULK_IMPORT_DATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_BULK_IMPORT_DATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_CNS_LOAN_APPLICATION', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_CNS_LOAN_APPLICATION_20', 0),
('WG_CNS_LOAN_APPLICATION', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_CNS_LOAN_APPLICATION', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_COLLATERAL_ADDRESS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_COLLATERAL_ADDRESS_20', 0),
('WG_COLLATERAL_ADDRESS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_COLLATERAL_ADDRESS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_COLLATERAL_PLEDGOR', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_COLLATERAL_PLEDGOR_20', 0),
('WG_COLLATERAL_PLEDGOR', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_COLLATERAL_PLEDGOR', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_COLLATERAL_TYPES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_COLLATERAL_TYPES_20', 0),
('WG_COLLATERAL_TYPES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_COLLATERAL_TYPES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_CORR_FUNDING', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_CORR_FUNDING_20', 0),
('WG_CORR_FUNDING', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_CORR_FUNDING', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_HMDAINFO_EXT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_HMDAINFO_EXT_20', 0),
('WG_HMDAINFO_EXT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_HMDAINFO_EXT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_HOEPA_DATA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_HOEPA_DATA_20', 0),
('WG_HOEPA_DATA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_HOEPA_DATA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_INCOME_SOURCE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_INCOME_SOURCE_20', 0),
('WG_INCOME_SOURCE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_INCOME_SOURCE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_KELLEYBLUEBOOK_RESPONSE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_KELLEYBLUEBOOK_RESPONSE_20', 0),
('WG_KELLEYBLUEBOOK_RESPONSE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_KELLEYBLUEBOOK_RESPONSE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_AMOUNTS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_AMOUNTS_20', 0),
('WG_RPT_AMOUNTS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_AMOUNTS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_BORROWER', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_BORROWER_20', 0),
('WG_RPT_BORROWER', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_BORROWER', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_CMS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_CMS_20', 0),
('WG_RPT_CMS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_CMS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_DATES', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_DATES_20', 0),
('WG_RPT_DATES', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_DATES', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_HMDA', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_HMDA_20', 0),
('WG_RPT_HMDA', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_HMDA', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_INV_LOCK_SNAPSHOT', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_INV_LOCK_SNAPSHOT_20', 0),
('WG_RPT_INV_LOCK_SNAPSHOT', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_INV_LOCK_SNAPSHOT', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_INVESTOR', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_INVESTOR_20', 0),
('WG_RPT_INVESTOR', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_INVESTOR', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_IPG_DETAIL_20', 0),
('WG_RPT_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_IPG_DETAIL', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_LOAN', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_LOAN_20', 0),
('WG_RPT_LOAN', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_LOAN', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_LOAN_ACTIVITY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_LOAN_ACTIVITY_20', 0),
('WG_RPT_LOAN_ACTIVITY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_LOAN_ACTIVITY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_LOAN_CONDITIONS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_LOAN_CONDITIONS_20', 0),
('WG_RPT_LOAN_CONDITIONS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_LOAN_CONDITIONS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_LOAN_REMARKS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_LOAN_REMARKS_20', 0),
('WG_RPT_LOAN_REMARKS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_LOAN_REMARKS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_LOAN_STATUS_20', 0),
('WG_RPT_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_LOAN_STATUS', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_PROPERTY', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_PROPERTY_20', 0),
('WG_RPT_PROPERTY', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_PROPERTY', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_RPT_WORKFLOW', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_RPT_WORKFLOW_20', 0),
('WG_RPT_WORKFLOW', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_RPT_WORKFLOW', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_SC_DECISION', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_SC_DECISION_20', 0),
('WG_SC_DECISION', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_SC_DECISION', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0),
('WG_TLBR_VET_MILT_SERVICE', @activity_id, @activity_name, 1, 'Source', 'src_file_prefix', 'Netoxygen_WG_TLBR_VET_MILT_SERVICE_20', 0),
('WG_TLBR_VET_MILT_SERVICE', @activity_id, @activity_name, 1, 'Source', 'pii_columns', '', 0),
('WG_TLBR_VET_MILT_SERVICE', @activity_id, @activity_name, 1, 'Source', 'ASAP_DeleteDateTime_mapping', NULL, 0)

PRINT 'Merge Data Object Parameter';

MERGE cntrl.data_object_parameter tgt
USING #data_object_parameter src
ON tgt.data_object_name = src.data_object_name
   AND tgt.activity_id = src.activity_id
   AND tgt.activity_name = src.activity_name
   AND tgt.context = src.context
   AND tgt.param_name = src.param_name
WHEN MATCHED AND (ISNULL(tgt.param_value, '0') <> ISNULL(src.param_value, '0') OR tgt.is_enabled <> src.is_enabled) THEN UPDATE SET
                                                                                                                          tgt.param_value = src.param_value,
                                                                                                                          tgt.is_enabled = src.is_enabled,
                                                                                                                          tgt.update_dttm = GETUTCDATE(),
                                                                                                                          tgt.updated_by = SUSER_SNAME()
WHEN NOT MATCHED THEN INSERT (data_object_name, activity_id, activity_name, is_enabled, context, param_name, param_value)
                      VALUES
                      (src.data_object_name, src.activity_id, src.activity_name, src.is_enabled, src.context, src.param_name, src.param_value);
GO
