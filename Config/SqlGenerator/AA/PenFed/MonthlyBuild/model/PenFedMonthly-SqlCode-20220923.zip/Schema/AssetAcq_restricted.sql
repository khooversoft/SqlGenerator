CREATE SCHEMA AssetAcq_restricted;
